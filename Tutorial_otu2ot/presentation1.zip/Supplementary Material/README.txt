
"tutorial3.RData"	contains the data needed to run Tutorial 3.

"AllOTU.RData" 		contains the data needed to run Tutorial 4.
			to load it type in a R console
			load("AllOTU.RData")